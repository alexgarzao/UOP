#include <stdio.h>
#include "sqlite3.h"
#include <pthread.h>
#include <dlfcn.h>
#include "database.h"


void database_open(void){
   int result;
   result = sqlite3_open("/home/lucksim/Downloads/data/banco.db", &db);
   if (result) {
//      printf("Não foi possível abrir o banco de dados. Erro:%s ", sqlite3_errmsg(db));
      sqlite3_close(db);
   } //else{ printf("o banco de dados foi aberto\n");}
  // }

   char *erro=NULL;
   int result2 = sqlite3_exec(db, "CREATE TABLE CLIENTE (NOME VARCHAR(50), IDADE INT)", NULL, NULL, &erro);
 //  if (erro!=NULL) {
       //se a tabela já existe pode acontecer erro... ignorar
     //printf("Não foi possível criar");
  // }
}

void insertData(char *local, char *activity, char *data) {
   char *sql;
   char *erro=NULL;
   
   int tamanho_char = strlen(local);
   int tamanho_char2 = strlen(activity);
   int tamanho_char3 = strlen(data);
   
   sql = (char *)malloc( sizeof(char) * 60+tamanho_char+tamanho_char2+tamanho_char3);
 
   sprintf(sql, "INSERT INTO TRAIL (LOCAL, ACTIVITY, DATA) VALUES ('%s', '%s', '%s')", local, activity, data);
   
   //sprintf(sql, "INSERT INTO TRAIL (LOCAL, ACTIVITY, DATA) VALUES ('%s', '%s', DATE('NOW'))", local, activity);
   
   int result2 = sqlite3_exec(db, sql, NULL, NULL, &erro);
}

void database_close(void) {
    sqlite3_close(db);
}

void insertData(void) {
     	
}


