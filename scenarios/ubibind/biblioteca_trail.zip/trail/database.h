#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>
#include "sqlite3.h"


static sqlite3 *db;

void database_open(void);
void database_close(void);
void insertData(char *local, char *activity, char *data);
//int main(void);

#ifdef __cplusplus
}
#endif
